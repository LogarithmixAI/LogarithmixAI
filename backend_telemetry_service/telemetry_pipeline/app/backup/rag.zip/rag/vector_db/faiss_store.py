import faiss
import numpy as np
import os
import pickle


class FAISSStore:

    def __init__(self, path, dim=384):
        self.path = path
        self.dim = dim

        index_file = f"{path}/index.faiss"
        texts_file = f"{path}/texts.pkl"

        if os.path.exists(index_file) and os.path.exists(texts_file):
            print("✅ Loading existing FAISS index")
            self.index = faiss.read_index(index_file)

            with open(texts_file, "rb") as f:
                self.texts = pickle.load(f)
        else:
            print("⚠️ Creating new FAISS index")
            self.index = faiss.IndexFlatL2(dim)
            self.texts = []

    def add(self, embeddings, texts):
        if len(embeddings) == 0:
            print("⚠️ No embeddings to add")
            return

        embeddings = np.array(embeddings).astype("float32")

        if len(embeddings.shape) == 1:
            embeddings = embeddings.reshape(1, -1)

        faiss.normalize_L2(embeddings)

        self.index.add(embeddings)
        self.texts.extend(texts)

    def search(self, query_embedding, k=5):
        query_embedding = np.array(query_embedding).astype("float32")

        if len(query_embedding.shape) == 1:
            query_embedding = query_embedding.reshape(1, -1)

        faiss.normalize_L2(query_embedding)

        D, I = self.index.search(query_embedding, k)

        results = []
        for idx in I[0]:
            if idx < len(self.texts):
                results.append(self.texts[idx])

        return results

    def save(self):
        os.makedirs(self.path, exist_ok=True)

        faiss.write_index(self.index, f"{self.path}/index.faiss")

        with open(f"{self.path}/texts.pkl", "wb") as f:
            pickle.dump(self.texts, f)