from app.rag.llm.gemini_client import GeminiClient
from app.rag.llm.prompt_builder import PromptBuilder
# import google.generativeai as genai



class ResponseGenerator:

    def __init__(self):
        self.llm = GeminiClient()
        self.prompt_builder = PromptBuilder()

    def generate(self, query, context):

        prompt = self.prompt_builder.build(query, context)

        return self.llm.generate(prompt)