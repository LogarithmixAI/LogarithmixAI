from app.storage.db import SessionLocal
from app.storage.models import LogModule, IdentityModule, Event, Batch
from app.rag.embeddings.embedder import Embedder
from app.rag.vector_db.faiss_store import FAISSStore
import re
from datetime import datetime


class IndexBuilder:

    def build(self, filters):

        db = SessionLocal()

        try:
            query = db.query(LogModule, IdentityModule, Event, Batch)\
                .join(Event, Event.id == LogModule.event_id)\
                .join(IdentityModule, IdentityModule.event_id == Event.id)\
                .join(Batch, Batch.id == Event.batch_id)

            if filters.get("project"):
                query = query.filter(Batch.project == filters["project"])

            if filters.get("environment"):
                query = query.filter(Batch.environment == filters["environment"])

            if filters.get("instance_id"):
                query = query.filter(IdentityModule.instance_id == filters["instance_id"])

            logs = query.all()

            print("FILTERS:", filters)
            print("LOG COUNT:", len(logs))

            # 🚨 SAFETY 1: No logs
            if not logs:
                print("⚠️ No logs found, skipping index build")
                return None
            
            def clean_text(text):
                return re.sub(r'\x1b\[[0-9;]*m', '', text)

            # def extract_endpoint(msg):
            #     import re
            #     match = re.search(r'/(\\w+)', msg)
            #     return match.group(0) if match else "unknown"


            def normalize_region(region):
                if not region or region.lower() in ["unknown", "unkown"]:
                    return "india"
                return region
            
            def format_time(ts):
                if isinstance(ts, str):
                    dt = datetime.fromisoformat(ts)
                else:
                    dt = ts

                return dt.strftime("%d %b %Y, %I:%M %p")      

            for (l, i, e, b) in logs:
                print(f"{l.level or 'UNKNOWN'}  [{normalize_region(i.region)}] {format_time(e.timestamp)} ---  [{e.severity or 'LOW'}] : "
                f"{clean_text(l.message)} | "
                f"project={b.project or 'unknown'} | "
                f"env={b.environment or 'unknown'} | ")

            texts = [
                f"{l.level or 'UNKNOWN'}  [{normalize_region(i.region)}] {format_time(e.timestamp)} ---  [{e.severity or 'LOW'}] : "
                f"{clean_text(l.message)} | "
                f"project={b.project or 'unknown'} | "
                f"env={b.environment or 'unknown'} | "
                for (l, i, e, b) in logs
            ]

            # 🚨 SAFETY 2: Empty texts
            if not texts:
                print("⚠️ No texts generated")
                return None

            embedder = Embedder()
            vectors = embedder.embed(texts)

            print("TEXT COUNT:", len(texts))
            print("EMBEDDINGS LEN:", len(vectors))

            # 🚨 SAFETY 3: Empty embeddings
            if vectors is None or len(vectors) == 0:
                print("⚠️ Empty embeddings, skipping FAISS")
                return None

            path = f"faiss_{filters.get('project')}_{filters.get('environment')}"

            store = FAISSStore(path=path)
            existing = set(store.texts)

            new_texts = [t for t in texts if t not in existing]

            if new_texts:
                vectors = embedder.embed(new_texts)
                store.add(vectors, new_texts)
                store.save()
            else:
                print("⚠️ No new logs to index")

            return store

        except Exception as e:
            print("❌ IndexBuilder ERROR:", e)
            return None

        finally:
            db.close()